#include "expression.h"
#include "common.h"
#include "queue.h"

#include <stdio.h>
#include <stdlib.h>

QUEUE infix_to_postfix(char *infixstr) {
  // create queue to store postfix expression
  QUEUE *queue = malloc(sizeof(QUEUE));
  queue->length = 0;
  queue->front = NULL;
  queue->rear = NULL;

  // create stack to store operators
  STACK *stack = malloc(sizeof(STACK));
  stack->length = 0;
  stack->top = NULL;
}

int evaluate_postfix(QUEUE queue) {}

int mypriority(char op) {
  if (op == '+' || op == '-') {
    return 0;
  } else if (op == '*' || op == '/' || op == '%') {
    return 1;
  }

  return -1;
}

int evaluate_infix(char *infix) {
  QUEUE postfix_queue = infix_to_postfix(infix);
  int result = evaluate_postfix(postfix_queue);
  queue_clean(&postfix_queue);
  return result;
}

void display(QUEUE *queue) {
  NODE *current = queue->front;
  printf("Postfix expression: ");
  while (current != NULL) {
    printf("%c ", current->data);  // Adjust format specifier based on `data` type
    current = current->next;
  }
  printf("\n");
}

